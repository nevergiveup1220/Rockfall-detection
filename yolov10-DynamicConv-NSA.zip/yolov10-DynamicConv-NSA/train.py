from ultralytics import YOLOv10
import warnings
warnings.filterwarnings('ignore')
# 模型配置文件
model_yaml_path = r"E:\basic learning\algorithm\yolov10-DynamicConv\ultralytics\cfg\models\v10\yolov10n_DynamicConv-NSA.yaml"
# 数据集配置文件
data_yaml_path = r'E:\basic learning\algorithm\yolov10-DynamicConv\datasets\data.yaml'
# 预训练模型路径（确保路径正确）
# pre_model_path = r'E:\basic learning\algorithm\yolov10-DynamicConv\pt\yolov10n.pt'  # 修改为实际路径

if __name__ == '__main__':
    # 加载预训练模型
    # model = YOLOv10(model_yaml_path).load(pre_model_path)
    # 不加载预训练模型
    model = YOLOv10(model_yaml_path)
    # 训练模型
    results = model.train(data=data_yaml_path,
                          imgsz=640,
                          epochs=300,
                          batch=8,
                          workers=0,
                          optimizer='NAdam',  #Adam, AdamW, NAdam, RAdam, RMSProp, SGD, auto
                          amp=False,
                          project='runs/V10train',
                          device=0,
                          name='YOLOv10_DynamicConv_NAdam_nopre',
                          )