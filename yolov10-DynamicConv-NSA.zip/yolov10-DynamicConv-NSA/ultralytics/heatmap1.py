import os
import sys
import cv2
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

# 添加项目路径
sys.path.append("E:/basic learning/algorithm/yolov10-DynamicConv-NSA")

# 修正导入模块
from ultralytics.utils import ops
from ultralytics.utils.ops import letterbox  # 导入letterbox函数
from ultralytics.nn.tasks import DetectionModel



class FeatureVisualizer:
    def __init__(self, model, img_size=640, device='cuda'):
        self.model = model.to(device)
        self.img_size = img_size
        self.device = device
        self.feature_maps = []
        self.handles = []

        # 注册所有卷积层的钩子
        for name, module in self.model.named_modules():
            if isinstance(module, nn.Conv2d):
                self.handles.append(
                    module.register_forward_hook(
                        lambda m, i, o: self.feature_maps.append(o.detach())
                    ))

    def preprocess(self, img_path):
        """完善的预处理流程"""
        # 读取并处理图像
        img = cv2.imread(img_path)
        if img is None:
            raise FileNotFoundError(f"Image {img_path} not found")

        # 使用letterbox进行智能缩放
        img = letterbox(img, self.img_size, stride=self.model.stride, auto=True)[0]  # 添加必要参数

        # 转换通道顺序
        img = img.transpose(2, 0, 1)  # HWC to CHW
        img = np.ascontiguousarray(img)

        # 转换为tensor并归一化
        img = torch.from_numpy(img).to(self.device)
        img = img.float() / 255.0
        return img.unsqueeze(0)  # 添加batch维度

    def visualize(self, img_path, save_dir='features'):
        """增强的可视化方法"""
        os.makedirs(save_dir, exist_ok=True)

        try:
            img_tensor = self.preprocess(img_path)
            with torch.no_grad():
                self.model(img_tensor)
        except Exception as e:
            print(f"Error during processing: {e}")
            return

        # 可视化每个特征层
        for layer_idx, feat_map in enumerate(self.feature_maps):
            # 转换为numpy并去除batch维度
            feat_map = feat_map[0].cpu().numpy()

            # 创建可视化布局
            num_channels = feat_map.shape[0]
            cols = 8
            rows = int(np.ceil(num_channels / cols))

            fig, axs = plt.subplots(rows, cols, figsize=(20, rows * 2.5))
            fig.suptitle(f'Layer {layer_idx} Feature Maps', fontsize=16)

            # 绘制每个通道
            for idx in range(num_channels):
                ax = axs[idx // cols, idx % cols]
                channel_map = feat_map[idx]

                # 归一化处理
                norm_map = (channel_map - channel_map.min()) / (channel_map.max() - channel_map.min() + 1e-6)

                ax.imshow(norm_map, cmap='jet')
                ax.axis('off')
                ax.set_title(f'Ch{idx}', fontsize=6)

            # 保存并清理
            plt.tight_layout()
            plt.savefig(os.path.join(save_dir, f'layer_{layer_idx}.png'), dpi=150)
            plt.close()


if __name__ == '__main__':
    # 安全加载权重（解决torch.load警告）
    def load_model():
        # 初始化模型
        model = DetectionModel(cfg='yolov10n.yaml')  # 使用实际配置文件路径

        # 安全加载权重
        weights_path = 'E:/basic learning/algorithm/yolov10-DynamicConv-NSA/pt/yolov10n.pt'
        ckpt = torch.load(weights_path, map_location='cpu', weights_only=True)  # 添加安全参数

        # 适配ultralytics的权重格式
        state_dict = ckpt.get('model', ckpt).float().state_dict()
        model.load_state_dict(state_dict)

        return model.eval()


    # 初始化可视化工具
    visualizer = FeatureVisualizer(load_model())

    # 执行可视化
    img_path = 'E:/basic learning/algorithm/yolov10-DynamicConv/datasets/data1/images/train/2299.jpg'
    visualizer.visualize(img_path)